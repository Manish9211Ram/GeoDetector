import torch
import torch.nn as nn
from torchvision import models, transforms
from PIL import Image
import numpy as np

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ----------------- Load model -----------------
model = models.resnet18(weights=None)
model.fc = nn.Linear(model.fc.in_features, 2)
model.load_state_dict(torch.load("best_map_model2.pth", map_location=device))
model.to(device)
model.eval()

# ----------------- ImageNet normalization -----------------
IMAGENET_MEAN = [0.485, 0.456, 0.406]
IMAGENET_STD  = [0.229, 0.224, 0.225]

transform = transforms.Compose([
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
    transforms.Normalize(IMAGENET_MEAN, IMAGENET_STD)
])

# ----------------- Prediction Function -----------------
def predict(image_path):
    image = Image.open(image_path).convert("RGB")
    image = transform(image).unsqueeze(0).to(device)

    with torch.no_grad():
        outputs = model(image)
        probs = torch.softmax(outputs, dim=1)[0]

    good_prob = probs[0].item()
    bad_prob  = probs[1].item()

    if good_prob >= bad_prob:
        label = "GOOD MAP"
        confidence = good_prob
    else:
        label = "BAD MAP"
        confidence = bad_prob

    print(f"Prediction: {label}")
    print(f"GOOD MAP: {good_prob*100:.2f}% | BAD MAP: {bad_prob*100:.2f}%")
    print(f"Confidence: {confidence*100:.2f}%")

    return {
        "label": label,
        "good_map_prob": round(good_prob*100, 2),
        "bad_map_prob": round(bad_prob*100, 2),
        "confidence": round(confidence*100, 2)
    }

# ----------------- Example -----------------
image_path = "good_maps\\WhatsApp Image 2026-02-06 at 3.34.08 PM.jpeg"
predict(image_path)




















